<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Movie;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class MovieController extends Controller
{
    public function index()
    {
        $movies = Movie::with('category')->get();
        return response()->json([
            'success' => true,
            'message' => 'Data film berhasil diambil',
            'data' => $movies
        ]);
    }

    public function show($id)
    {
        $movie = Movie::with('category')->find($id);

        if (!$movie) {
            return response()->json([
                'success' => false,
                'message' => 'Data tidak ditemukan'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'message' => 'Detail film berhasil diambil',
            'data' => $movie
        ]);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'rating' => 'required|numeric|min:0|max:10',
            'release_year' => 'required|integer|min:1900|max:2030',
            'category_id' => 'required|exists:movie_category,id',
            'thumbnail' => 'nullable|string'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validasi gagal',
                'errors' => $validator->errors()
            ], 422);
        }

        $movie = Movie::create($request->all());

        return response()->json([
            'success' => true,
            'message' => 'Film berhasil ditambahkan',
            'data' => $movie
        ]);
    }

    public function update(Request $request, $id)
    {
        $movie = Movie::find($id);

        if (!$movie) {
            return response()->json([
                'success' => false,
                'message' => 'Data tidak ditemukan'
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'rating' => 'required|numeric|min:0|max:10',
            'release_year' => 'required|integer|min:1900|max:2030',
            'category_id' => 'required|exists:movie_category,id',
            'thumbnail' => 'nullable|string'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validasi gagal',
                'errors' => $validator->errors()
            ], 422);
        }

        $movie->update($request->all());

        return response()->json([
            'success' => true,
            'message' => 'Film berhasil diperbarui',
            'data' => $movie
        ]);
    }

    public function destroy($id)
    {
        $movie = Movie::find($id);

        if (!$movie) {
            return response()->json([
                'success' => false,
                'message' => 'Data tidak ditemukan'
            ], 404);
        }

        $movie->delete();

        return response()->json([
            'success' => true,
            'message' => 'Film berhasil dihapus',
            'data' => null
        ]);
    }
}
